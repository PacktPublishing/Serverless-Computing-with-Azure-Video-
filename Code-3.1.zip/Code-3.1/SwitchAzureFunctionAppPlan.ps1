Set-Location C:\
Clear-Host

#List the names of the web apps (function apps) in the resource group
Get-AzureRMWebApp -ResourceGroupName "packt-serverless" | Select-Object Name 

#List the web app service plans in the resource group
Get-AzureRmAppServicePlan -ResourceGroupName "packt-serverless"| Select-Object Name, Kind 

#Switch to the Basic Web App Plan
Set-AzureRmWebApp -ResourceGroupName "packt-serverless" `
    -Name "PacktFunctionAppFromVSCode" `
    -AppServicePlan "BasicAppServicePlan" 

#Switch to the Consumption Plan
Set-AzureRmWebApp -ResourceGroupName "packt-serverless" `
    -Name "PacktFunctionAppFromVSCode" `
    -AppServicePlan "CentralUSPlan" 
